<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("location: welcome.php");
    exit;
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];
    
    // Check if password is valid
    if ($password === 'ken') {
        $_SESSION['loggedin'] = true;
        header("location: welcome.php");
        exit;
    } else {
        $error = 'Invalid AcessCode';
        
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <style>
        body {
            background-color: #111;
            color: #fff;
        }
        form {
            background-color: #222;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            margin: auto;
            margin-top: 100px;
        }
        input[type="password"] {
            border: none;
            background-color: #333;
            color: #fff;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            width: 100%;
        }
        button[type="submit"] {
            background-color: #00bcd4;
            border: none;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        button[type="submit"]:hover {
            background-color: #0097a7;
        }
        div.error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <form method="post">
        <?php if (isset($error)) { ?>
            <div class="error"><?php echo $error; ?></div>
        <?php } ?>
        <div>
        <h1>HAILEY KEN CHK</h1>
            <label>ACESS CODE:</label>
            <input type="password" name="password" required>
        </div>
        
        <div>
            <button type="submit">Login</button>
        </div>
    </form>
</body>
</html>
